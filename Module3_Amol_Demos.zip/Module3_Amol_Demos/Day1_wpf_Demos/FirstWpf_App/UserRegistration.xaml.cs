﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FirstWpf_App
{
    /// <summary>
    /// Interaction logic for UserRegistration.xaml
    /// </summary>
    public partial class UserRegistration : Window
    {
        public UserRegistration()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder sbData = new StringBuilder();

            sbData.Append("Full Name: " + txtFullName.Text);

            if (rbMale.IsChecked == true)
                sbData.Append("\nGender: " + rbMale.Content);
            else if (rbFemale.IsChecked == true)
                sbData.Append("\nGender: " + rbFemale.Content);

            DateTime dob = (DateTime)dpDOB.SelectedDate;
            sbData.Append("\nDOB: " + dob.ToString("dd-MMM-yyyy"));

            rtbAddress.SelectAll();
            sbData.Append("\nAddress: " + rtbAddress.Selection.Text);

            //ListBoxItem it = (ListBoxItem) lbHighQual.SelectedItem;
            //if(it != null ) 
            //{
            //    sbData.Append("High Qual: "+it.Content);
            //}

            sbData.Append("\nHigh Qual: " + lbHighQual.Text);

            MessageBox.Show(sbData.ToString());
        }
    }
}
